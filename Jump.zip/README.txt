A Pen created at CodePen.io. You can find this one at http://codepen.io/shanyuwsy/pen/YqxBvG.

 

Forked from [Nickey Khem](http://codepen.io/nike121/)'s Pen [zEtBh](http://codepen.io/nike121/pen/zEtBh/).